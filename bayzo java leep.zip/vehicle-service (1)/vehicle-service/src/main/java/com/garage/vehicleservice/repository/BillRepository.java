package com.garage.vehicleservice.repository;

import com.garage.vehicleservice.entity.Bill;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillRepository extends JpaRepository<Bill, Long> {

    boolean existsByJobCardId(Long jobCardId);
}