package com.garage.vehicleservice.repository;

import com.garage.vehicleservice.entity.Bay;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BayRepository extends JpaRepository<Bay, Long> {
}