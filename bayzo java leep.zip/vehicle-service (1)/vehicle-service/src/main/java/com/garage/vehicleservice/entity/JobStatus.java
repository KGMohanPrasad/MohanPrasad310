package com.garage.vehicleservice.entity;

public enum JobStatus {

    WAITING,
    IN_PROGRESS,
    QUALITY_CHECK,
    COMPLETED
}