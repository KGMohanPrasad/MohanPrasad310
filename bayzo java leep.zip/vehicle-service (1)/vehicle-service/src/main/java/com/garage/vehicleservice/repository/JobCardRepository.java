package com.garage.vehicleservice.repository;

import com.garage.vehicleservice.entity.JobCard;
import com.garage.vehicleservice.entity.JobStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;

public interface JobCardRepository extends JpaRepository<JobCard, Long> {

    boolean existsByBayIdAndStatusIn(
            Long bayId,
            Collection<JobStatus> statuses
    );

    boolean existsByMechanicIdAndStatusIn(
            Long mechanicId,
            Collection<JobStatus> statuses
    );
}