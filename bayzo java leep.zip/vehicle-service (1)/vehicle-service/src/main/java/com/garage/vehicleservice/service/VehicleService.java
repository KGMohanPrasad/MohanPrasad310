package com.garage.vehicleservice.service;

import com.garage.vehicleservice.dto.VehicleRequest;
import com.garage.vehicleservice.entity.Vehicle;
import com.garage.vehicleservice.exception.BusinessException;
import com.garage.vehicleservice.repository.VehicleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {

    private final VehicleRepository vehicleRepository;

    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }

    public Vehicle createVehicle(VehicleRequest request) {

        if (vehicleRepository.existsByRegistrationNumber(
                request.getRegistrationNumber())) {

            throw new BusinessException(
                    "Vehicle registration number already exists"
            );
        }

        Vehicle vehicle = new Vehicle();

        vehicle.setRegistrationNumber(request.getRegistrationNumber());
        vehicle.setOwnerName(request.getOwnerName());
        vehicle.setPhoneNumber(request.getPhoneNumber());
        vehicle.setBrand(request.getBrand());
        vehicle.setModel(request.getModel());

        return vehicleRepository.save(vehicle);
    }

    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }
}