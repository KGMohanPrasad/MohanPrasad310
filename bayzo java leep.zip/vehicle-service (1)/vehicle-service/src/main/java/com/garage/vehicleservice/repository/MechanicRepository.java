package com.garage.vehicleservice.repository;

import com.garage.vehicleservice.entity.Mechanic;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MechanicRepository extends JpaRepository<Mechanic, Long> {
}