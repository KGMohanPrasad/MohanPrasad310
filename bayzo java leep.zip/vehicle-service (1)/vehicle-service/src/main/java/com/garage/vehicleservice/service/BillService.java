package com.garage.vehicleservice.service;

import com.garage.vehicleservice.dto.BillRequest;
import com.garage.vehicleservice.entity.Bill;
import com.garage.vehicleservice.entity.JobCard;
import com.garage.vehicleservice.entity.JobStatus;
import com.garage.vehicleservice.exception.BusinessException;
import com.garage.vehicleservice.exception.ResourceNotFoundException;
import com.garage.vehicleservice.repository.BillRepository;
import com.garage.vehicleservice.repository.JobCardRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BillService {

    private final BillRepository billRepository;
    private final JobCardRepository jobCardRepository;

    public BillService(
            BillRepository billRepository,
            JobCardRepository jobCardRepository) {

        this.billRepository = billRepository;
        this.jobCardRepository = jobCardRepository;
    }

    @Transactional
    public Bill generateBill(
            Long jobId,
            BillRequest request) {

        JobCard job = jobCardRepository
                .findById(jobId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Job card not found with id: " + jobId
                        )
                );

        if (job.getStatus() != JobStatus.COMPLETED) {
            throw new BusinessException(
                    "Bill can only be generated for completed jobs"
            );
        }

        if (billRepository.existsByJobCardId(jobId)) {
            throw new BusinessException(
                    "Bill already exists for this job"
            );
        }

        Bill bill = new Bill();

        bill.setJobCard(job);
        bill.setLabourCharge(request.getLabourCharge());
        bill.setPartsTotal(request.getPartsTotal());

        bill.setGrandTotal(
                request.getLabourCharge()
                        .add(request.getPartsTotal())
        );

        return billRepository.save(bill);
    }
}