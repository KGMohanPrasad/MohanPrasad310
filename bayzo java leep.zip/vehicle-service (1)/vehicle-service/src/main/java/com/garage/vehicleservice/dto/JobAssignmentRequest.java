package com.garage.vehicleservice.dto;

import jakarta.validation.constraints.NotNull;

public class JobAssignmentRequest {

    @NotNull(message = "Bay ID is required")
    private Long bayId;

    @NotNull(message = "Mechanic ID is required")
    private Long mechanicId;

    public Long getBayId() {
        return bayId;
    }

    public void setBayId(Long bayId) {
        this.bayId = bayId;
    }

    public Long getMechanicId() {
        return mechanicId;
    }

    public void setMechanicId(Long mechanicId) {
        this.mechanicId = mechanicId;
    }
}