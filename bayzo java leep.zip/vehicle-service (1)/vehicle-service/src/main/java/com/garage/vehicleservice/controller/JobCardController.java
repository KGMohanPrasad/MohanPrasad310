package com.garage.vehicleservice.controller;

import com.garage.vehicleservice.dto.JobAssignmentRequest;
import com.garage.vehicleservice.dto.JobCardRequest;
import com.garage.vehicleservice.entity.JobCard;
import com.garage.vehicleservice.service.JobCardService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/job-cards")
public class JobCardController {

    private final JobCardService jobCardService;

    public JobCardController(
            JobCardService jobCardService) {

        this.jobCardService = jobCardService;
    }

    @PostMapping
    public ResponseEntity<JobCard> createJob(
            @Valid @RequestBody JobCardRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(jobCardService.createJob(request));
    }

    @GetMapping
    public ResponseEntity<List<JobCard>> getAllJobs() {

        return ResponseEntity.ok(
                jobCardService.getAllJobs()
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobCard> getJob(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                jobCardService.getJobById(id)
        );
    }

    @PutMapping("/{id}/assign")
    public ResponseEntity<JobCard> assignJob(
            @PathVariable Long id,
            @Valid @RequestBody
            JobAssignmentRequest request) {

        return ResponseEntity.ok(
                jobCardService.assignJob(id, request)
        );
    }

    @PutMapping("/{id}/start")
    public ResponseEntity<JobCard> startJob(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                jobCardService.startJob(id)
        );
    }

    @PutMapping("/{id}/quality-check")
    public ResponseEntity<JobCard> qualityCheck(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                jobCardService.moveToQualityCheck(id)
        );
    }

    @PutMapping("/{id}/quality-check/pass")
    public ResponseEntity<JobCard> passQualityCheck(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                jobCardService.passQualityCheck(id)
        );
    }

    @PutMapping("/{id}/complete")
    public ResponseEntity<JobCard> completeJob(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                jobCardService.completeJob(id)
        );
    }
}