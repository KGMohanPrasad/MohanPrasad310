package com.garage.vehicleservice.controller;

import com.garage.vehicleservice.entity.Mechanic;
import com.garage.vehicleservice.service.MechanicService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mechanics")
public class MechanicController {

    private final MechanicService mechanicService;

    public MechanicController(MechanicService mechanicService) {
        this.mechanicService = mechanicService;
    }

    @PostMapping
    public ResponseEntity<Mechanic> createMechanic(
            @RequestBody Mechanic mechanic) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(mechanicService.createMechanic(mechanic));
    }

    @GetMapping
    public ResponseEntity<List<Mechanic>> getAllMechanics() {
        return ResponseEntity.ok(
                mechanicService.getAllMechanics()
        );
    }
}