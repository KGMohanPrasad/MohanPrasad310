package com.garage.vehicleservice.service;

import com.garage.vehicleservice.dto.JobAssignmentRequest;
import com.garage.vehicleservice.dto.JobCardRequest;
import com.garage.vehicleservice.entity.Bay;
import com.garage.vehicleservice.entity.JobCard;
import com.garage.vehicleservice.entity.JobStatus;
import com.garage.vehicleservice.entity.Mechanic;
import com.garage.vehicleservice.entity.Vehicle;
import com.garage.vehicleservice.exception.BusinessException;
import com.garage.vehicleservice.exception.ResourceNotFoundException;
import com.garage.vehicleservice.repository.BayRepository;
import com.garage.vehicleservice.repository.JobCardRepository;
import com.garage.vehicleservice.repository.MechanicRepository;
import com.garage.vehicleservice.repository.VehicleRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class JobCardService {

    private final JobCardRepository jobCardRepository;
    private final VehicleRepository vehicleRepository;
    private final BayRepository bayRepository;
    private final MechanicRepository mechanicRepository;

    public JobCardService(
            JobCardRepository jobCardRepository,
            VehicleRepository vehicleRepository,
            BayRepository bayRepository,
            MechanicRepository mechanicRepository) {

        this.jobCardRepository = jobCardRepository;
        this.vehicleRepository = vehicleRepository;
        this.bayRepository = bayRepository;
        this.mechanicRepository = mechanicRepository;
    }

    @Transactional
    public JobCard createJob(JobCardRequest request) {

        Vehicle vehicle = vehicleRepository
                .findById(request.getVehicleId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Vehicle not found with id: "
                                        + request.getVehicleId()
                        )
                );

        JobCard jobCard = new JobCard();

        jobCard.setVehicle(vehicle);
        jobCard.setRequestedService(request.getRequestedService());
        jobCard.setStatus(JobStatus.WAITING);

        return jobCardRepository.save(jobCard);
    }

    public List<JobCard> getAllJobs() {
        return jobCardRepository.findAll();
    }

    public JobCard getJobById(Long id) {

        return jobCardRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Job card not found with id: " + id
                        )
                );
    }

    @Transactional
    public JobCard assignJob(
            Long jobId,
            JobAssignmentRequest request) {

        JobCard job = getJobById(jobId);

        if (job.getStatus() != JobStatus.WAITING) {
            throw new BusinessException(
                    "Only WAITING jobs can be assigned"
            );
        }

        Bay bay = bayRepository
                .findById(request.getBayId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Bay not found with id: "
                                        + request.getBayId()
                        )
                );

        Mechanic mechanic = mechanicRepository
                .findById(request.getMechanicId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Mechanic not found with id: "
                                        + request.getMechanicId()
                        )
                );

        if (!bay.isActive()) {
            throw new BusinessException(
                    "Selected bay is inactive"
            );
        }

        if (!mechanic.isActive()) {
            throw new BusinessException(
                    "Selected mechanic is inactive"
            );
        }

        List<JobStatus> activeStatuses = List.of(
                JobStatus.WAITING,
                JobStatus.IN_PROGRESS,
                JobStatus.QUALITY_CHECK
        );

        boolean bayOccupied =
                jobCardRepository.existsByBayIdAndStatusIn(
                        bay.getId(),
                        activeStatuses
                );

        if (bayOccupied) {
            throw new BusinessException(
                    "Bay is already occupied by another active job"
            );
        }

        boolean mechanicBusy =
                jobCardRepository.existsByMechanicIdAndStatusIn(
                        mechanic.getId(),
                        activeStatuses
                );

        if (mechanicBusy) {
            throw new BusinessException(
                    "Mechanic is already assigned to another active job"
            );
        }

        job.setBay(bay);
        job.setMechanic(mechanic);

        return jobCardRepository.save(job);
    }

    @Transactional
    public JobCard startJob(Long id) {

        JobCard job = getJobById(id);

        if (job.getStatus() != JobStatus.WAITING) {
            throw new BusinessException(
                    "Only WAITING jobs can be started"
            );
        }

        if (job.getBay() == null) {
            throw new BusinessException(
                    "Bay must be assigned before starting the job"
            );
        }

        if (job.getMechanic() == null) {
            throw new BusinessException(
                    "Mechanic must be assigned before starting the job"
            );
        }

        job.setStatus(JobStatus.IN_PROGRESS);

        return jobCardRepository.save(job);
    }

    @Transactional
    public JobCard moveToQualityCheck(Long id) {

        JobCard job = getJobById(id);

        if (job.getStatus() != JobStatus.IN_PROGRESS) {
            throw new BusinessException(
                    "Only IN_PROGRESS jobs can move to quality check"
            );
        }

        job.setQualityCheckPassed(false);
        job.setStatus(JobStatus.QUALITY_CHECK);

        return jobCardRepository.save(job);
    }

    @Transactional
    public JobCard passQualityCheck(Long id) {

        JobCard job = getJobById(id);

        if (job.getStatus() != JobStatus.QUALITY_CHECK) {
            throw new BusinessException(
                    "Job must be in QUALITY_CHECK status"
            );
        }

        job.setQualityCheckPassed(true);

        return jobCardRepository.save(job);
    }

    @Transactional
    public JobCard completeJob(Long id) {

        JobCard job = getJobById(id);

        if (job.getStatus() != JobStatus.QUALITY_CHECK) {
            throw new BusinessException(
                    "Job must be in QUALITY_CHECK status before completion"
            );
        }

        if (!job.isQualityCheckPassed()) {
            throw new BusinessException(
                    "Quality check must pass before completing the job"
            );
        }

        job.setStatus(JobStatus.COMPLETED);
        job.setCompletedAt(LocalDateTime.now());

        return jobCardRepository.save(job);
    }
}