package com.garage.vehicleservice.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "bills")
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    @JoinColumn(name = "job_card_id", nullable = false, unique = true)
    private JobCard jobCard;

    @Column(nullable = false)
    private BigDecimal labourCharge;

    @Column(nullable = false)
    private BigDecimal partsTotal;

    @Column(nullable = false)
    private BigDecimal grandTotal;

    @Column(nullable = false, updatable = false)
    private LocalDateTime generatedAt;

    public Bill() {
    }

    @PrePersist
    public void onCreate() {
        generatedAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public JobCard getJobCard() {
        return jobCard;
    }

    public void setJobCard(JobCard jobCard) {
        this.jobCard = jobCard;
    }

    public BigDecimal getLabourCharge() {
        return labourCharge;
    }

    public void setLabourCharge(BigDecimal labourCharge) {
        this.labourCharge = labourCharge;
    }

    public BigDecimal getPartsTotal() {
        return partsTotal;
    }

    public void setPartsTotal(BigDecimal partsTotal) {
        this.partsTotal = partsTotal;
    }

    public BigDecimal getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(BigDecimal grandTotal) {
        this.grandTotal = grandTotal;
    }

    public LocalDateTime getGeneratedAt() {
        return generatedAt;
    }
}