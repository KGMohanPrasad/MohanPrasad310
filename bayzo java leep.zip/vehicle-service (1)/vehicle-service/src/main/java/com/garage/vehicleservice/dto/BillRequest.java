package com.garage.vehicleservice.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

public class BillRequest {

    @NotNull(message = "Labour charge is required")
    @PositiveOrZero(message = "Labour charge cannot be negative")
    private BigDecimal labourCharge;

    @NotNull(message = "Parts total is required")
    @PositiveOrZero(message = "Parts total cannot be negative")
    private BigDecimal partsTotal;

    public BigDecimal getLabourCharge() {
        return labourCharge;
    }

    public void setLabourCharge(BigDecimal labourCharge) {
        this.labourCharge = labourCharge;
    }

    public BigDecimal getPartsTotal() {
        return partsTotal;
    }

    public void setPartsTotal(BigDecimal partsTotal) {
        this.partsTotal = partsTotal;
    }
}