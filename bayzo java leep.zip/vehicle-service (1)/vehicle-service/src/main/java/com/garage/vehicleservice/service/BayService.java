package com.garage.vehicleservice.service;

import com.garage.vehicleservice.entity.Bay;
import com.garage.vehicleservice.repository.BayRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BayService {

    private final BayRepository bayRepository;

    public BayService(BayRepository bayRepository) {
        this.bayRepository = bayRepository;
    }

    public Bay createBay(Bay bay) {
        return bayRepository.save(bay);
    }

    public List<Bay> getAllBays() {
        return bayRepository.findAll();
    }
}