package com.garage.vehicleservice.controller;

import com.garage.vehicleservice.entity.Bay;
import com.garage.vehicleservice.service.BayService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bays")
public class BayController {

    private final BayService bayService;

    public BayController(BayService bayService) {
        this.bayService = bayService;
    }

    @PostMapping
    public ResponseEntity<Bay> createBay(@RequestBody Bay bay) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(bayService.createBay(bay));
    }

    @GetMapping
    public ResponseEntity<List<Bay>> getAllBays() {
        return ResponseEntity.ok(bayService.getAllBays());
    }
}