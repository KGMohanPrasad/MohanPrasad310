package com.garage.vehicleservice.controller;

import com.garage.vehicleservice.dto.BillRequest;
import com.garage.vehicleservice.entity.Bill;
import com.garage.vehicleservice.service.BillService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bills")
public class BillController {

    private final BillService billService;

    public BillController(
            BillService billService) {

        this.billService = billService;
    }

    @PostMapping("/job/{jobId}")
    public ResponseEntity<Bill> generateBill(
            @PathVariable Long jobId,
            @Valid @RequestBody BillRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(
                        billService.generateBill(
                                jobId,
                                request
                        )
                );
    }
}