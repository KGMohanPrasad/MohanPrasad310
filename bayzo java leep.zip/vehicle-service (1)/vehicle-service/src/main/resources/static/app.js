const API = "/api";

document.addEventListener("DOMContentLoaded", () => {
    bindForms();
    refreshAll();
});

function bindForms() {
    document.getElementById("vehicleForm").addEventListener("submit", createVehicle);
    document.getElementById("bayForm").addEventListener("submit", createBay);
    document.getElementById("mechanicForm").addEventListener("submit", createMechanic);
    document.getElementById("jobForm").addEventListener("submit", createJob);
    document.getElementById("assignForm").addEventListener("submit", assignJob);
    document.getElementById("billForm").addEventListener("submit", generateBill);
}

/* ==========================
   COMMON API METHOD
========================== */
async function apiRequest(url, options = {}) {
    try {
        const response = await fetch(url, options);
        let data = null;
        const text = await response.text();

        if (text) {
            try {
                data = JSON.parse(text);
            } catch {
                data = text;
            }
        }

        if (!response.ok) {
            let message = `Request failed (${response.status})`;

            if (data && typeof data === 'object') {
                if (data.message) {
                    message = data.message;
                } else if (data.messages && typeof data.messages === 'object') {
                    message = Object.values(data.messages).join(", ");
                } else if (data.error) {
                    message = data.error;
                }
            } else if (typeof data === 'string' && data.trim()) {
                message = data;
            }

            throw new Error(message);
        }

        return data;
    } catch (error) {
        showToast(error.message, true);
        throw error;
    }
}

/* ==========================
   1. VEHICLES
========================== */
async function createVehicle(event) {
    event.preventDefault();

    const regInput = document.getElementById("registrationNumber").value.trim();
    const ownerInput = document.getElementById("ownerName").value.trim();

    const phoneInput = document.getElementById("phoneNumber").value.trim();

    if (!regInput) {
        showToast("Registration number is required", true);
        return;
    }

    if (!ownerInput) {
        showToast("Owner name is required", true);
        return;
    }

    if (phoneInput && !/^[0-9+\-\s()]{7,15}$/.test(phoneInput)) {
        showToast("Error: Phone number must contain only numbers (digits), not letters or special words", true);
        return;
    }

    const vehicle = {
        registrationNumber: regInput,
        ownerName: ownerInput,
        phoneNumber: phoneInput,
        brand: document.getElementById("brand").value.trim(),
        model: document.getElementById("model").value.trim()
    };

    try {
        await apiRequest(`${API}/vehicles`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(vehicle)
        });

        document.getElementById("vehicleForm").reset();
        showToast("Vehicle registered successfully");
        await loadVehicles();
    } catch (error) {
        console.error(error);
    }
}

async function loadVehicles() {
    try {
        const vehicles = await apiRequest(`${API}/vehicles`);
        const table = document.getElementById("vehicleTable");
        table.innerHTML = "";

        if (!vehicles || vehicles.length === 0) {
            table.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#64748b;">No vehicles registered yet.</td></tr>`;
        } else {
            vehicles.forEach(vehicle => {
                table.innerHTML += `
                    <tr>
                        <td><strong>#${vehicle.id}</strong></td>
                        <td><strong>${vehicle.registrationNumber}</strong></td>
                        <td>${vehicle.ownerName}</td>
                        <td>${vehicle.phoneNumber || "-"}</td>
                        <td>${vehicle.brand || "-"}</td>
                        <td>${vehicle.model || "-"}</td>
                    </tr>
                `;
            });
        }

        document.getElementById("vehicleCount").textContent = vehicles ? vehicles.length : 0;
        updateVehicleSelect(vehicles || []);
    } catch (error) {
        console.error(error);
    }
}

function updateVehicleSelect(vehicles) {
    const select = document.getElementById("jobVehicleId");
    select.innerHTML = `<option value="">Select Vehicle *</option>`;

    vehicles.forEach(vehicle => {
        select.innerHTML += `
            <option value="${vehicle.id}">
                ${vehicle.registrationNumber} - ${vehicle.ownerName}
            </option>
        `;
    });
}

/* ==========================
   2. SERVICE BAYS
========================== */
async function createBay(event) {
    event.preventDefault();

    const bayNumber = document.getElementById("bayNumber").value.trim();
    if (!bayNumber) {
        showToast("Bay number is required", true);
        return;
    }

    const bay = {
        bayNumber: bayNumber,
        active: document.getElementById("bayActive").value === "true"
    };

    try {
        await apiRequest(`${API}/bays`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(bay)
        });

        document.getElementById("bayForm").reset();
        showToast("Service Bay created successfully");
        await loadBays();
    } catch (error) {
        console.error(error);
    }
}

async function loadBays() {
    try {
        const bays = await apiRequest(`${API}/bays`);
        const table = document.getElementById("bayTable");
        table.innerHTML = "";

        if (!bays || bays.length === 0) {
            table.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#64748b;">No service bays created yet.</td></tr>`;
        } else {
            bays.forEach(bay => {
                table.innerHTML += `
                    <tr>
                        <td><strong>#${bay.id}</strong></td>
                        <td>${bay.bayNumber}</td>
                        <td>
                            <span class="status ${bay.active ? 'COMPLETED' : 'WAITING'}">
                                ${bay.active ? "✅ Active" : "❌ Inactive"}
                            </span>
                        </td>
                    </tr>
                `;
            });
        }

        document.getElementById("bayCount").textContent = bays ? bays.length : 0;
        updateBaySelect(bays || []);
    } catch (error) {
        console.error(error);
    }
}

function updateBaySelect(bays) {
    const select = document.getElementById("assignBayId");
    select.innerHTML = `<option value="">Select Bay *</option>`;

    bays
        .filter(bay => bay.active)
        .forEach(bay => {
            select.innerHTML += `
                <option value="${bay.id}">
                    ${bay.bayNumber}
                </option>
            `;
        });
}

/* ==========================
   3. MECHANICS
========================== */
async function createMechanic(event) {
    event.preventDefault();

    const name = document.getElementById("mechanicName").value.trim();
    if (!name) {
        showToast("Mechanic name is required", true);
        return;
    }

    const mechanic = {
        name: name,
        specialization: document.getElementById("specialization").value.trim(),
        active: document.getElementById("mechanicActive").value === "true"
    };

    try {
        await apiRequest(`${API}/mechanics`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(mechanic)
        });

        document.getElementById("mechanicForm").reset();
        showToast("Mechanic registered successfully");
        await loadMechanics();
    } catch (error) {
        console.error(error);
    }
}

async function loadMechanics() {
    try {
        const mechanics = await apiRequest(`${API}/mechanics`);
        const table = document.getElementById("mechanicTable");
        table.innerHTML = "";

        if (!mechanics || mechanics.length === 0) {
            table.innerHTML = `<tr><td colspan="4" style="text-align:center; color:#64748b;">No mechanics added yet.</td></tr>`;
        } else {
            mechanics.forEach(mechanic => {
                table.innerHTML += `
                    <tr>
                        <td><strong>#${mechanic.id}</strong></td>
                        <td>${mechanic.name}</td>
                        <td>${mechanic.specialization || "-"}</td>
                        <td>
                            <span class="status ${mechanic.active ? 'COMPLETED' : 'WAITING'}">
                                ${mechanic.active ? "✅ Active" : "❌ Inactive"}
                            </span>
                        </td>
                    </tr>
                `;
            });
        }

        document.getElementById("mechanicCount").textContent = mechanics ? mechanics.length : 0;
        updateMechanicSelect(mechanics || []);
    } catch (error) {
        console.error(error);
    }
}

function updateMechanicSelect(mechanics) {
    const select = document.getElementById("assignMechanicId");
    select.innerHTML = `<option value="">Select Mechanic *</option>`;

    mechanics
        .filter(mechanic => mechanic.active)
        .forEach(mechanic => {
            select.innerHTML += `
                <option value="${mechanic.id}">
                    ${mechanic.name} - ${mechanic.specialization || "General"}
                </option>
            `;
        });
}

/* ==========================
   4. JOB CARDS
========================== */
async function createJob(event) {
    event.preventDefault();

    const vehicleIdRaw = document.getElementById("jobVehicleId").value;
    const requestedService = document.getElementById("requestedService").value.trim();

    if (!vehicleIdRaw || isNaN(vehicleIdRaw)) {
        showToast("Error: Vehicle ID must be a valid number. Please select a vehicle.", true);
        return;
    }

    if (!requestedService) {
        showToast("Error: Requested service is required", true);
        return;
    }

    const job = {
        vehicleId: Number(vehicleIdRaw),
        requestedService: requestedService
    };

    try {
        await apiRequest(`${API}/job-cards`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(job)
        });

        document.getElementById("jobForm").reset();
        showToast("Job card created successfully");
        await loadJobs();
    } catch (error) {
        console.error(error);
    }
}

async function loadJobs() {
    try {
        const jobs = await apiRequest(`${API}/job-cards`);
        const table = document.getElementById("jobTable");
        table.innerHTML = "";

        if (!jobs || jobs.length === 0) {
            table.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#64748b;">No job cards created yet.</td></tr>`;
        } else {
            jobs.forEach(job => {
                table.innerHTML += `
                    <tr>
                        <td><strong>#${job.id}</strong></td>
                        <td>${job.vehicle ? job.vehicle.registrationNumber : "-"}</td>
                        <td>${job.requestedService}</td>
                        <td>${job.bay ? job.bay.bayNumber : "Not Assigned"}</td>
                        <td>${job.mechanic ? job.mechanic.name : "Not Assigned"}</td>
                        <td>
                            <span class="status ${job.status}">
                                ${job.status}
                            </span>
                        </td>
                        <td>
                            ${job.qualityCheckPassed ? "✅ Passed" : "⏳ Pending"}
                        </td>
                        <td>${formatDate(job.createdAt)}</td>
                        <td>${formatDate(job.completedAt)}</td>
                    </tr>
                `;
            });
        }

        document.getElementById("jobCount").textContent = jobs ? jobs.length : 0;
        updateJobSelects(jobs || []);
    } catch (error) {
        console.error(error);
    }
}

function updateJobSelects(jobs) {
    const assign = document.getElementById("assignJobId");
    const workflow = document.getElementById("workflowJobId");
    const bill = document.getElementById("billJobId");

    assign.innerHTML = `<option value="">Select Waiting Job *</option>`;
    workflow.innerHTML = `<option value="">Select Job *</option>`;
    bill.innerHTML = `<option value="">Select Completed Job *</option>`;

    jobs.forEach(job => {
        const label = `Job #${job.id} - ${job.vehicle ? job.vehicle.registrationNumber : ""} - ${job.status}`;

        workflow.innerHTML += `
            <option value="${job.id}">
                ${label}
            </option>
        `;

        if (job.status === "WAITING") {
            assign.innerHTML += `
                <option value="${job.id}">
                    ${label}
                </option>
            `;
        }

        if (job.status === "COMPLETED") {
            bill.innerHTML += `
                <option value="${job.id}">
                    ${label}
                </option>
            `;
        }
    });
}

/* ==========================
   5. ASSIGN JOB (BAY & MECHANIC)
========================== */
async function assignJob(event) {
    event.preventDefault();

    const jobIdRaw = document.getElementById("assignJobId").value;
    const bayIdRaw = document.getElementById("assignBayId").value;
    const mechanicIdRaw = document.getElementById("assignMechanicId").value;

    if (!jobIdRaw || isNaN(jobIdRaw)) {
        showToast("Error: Job ID must be a valid number", true);
        return;
    }

    if (!bayIdRaw || isNaN(bayIdRaw)) {
        showToast("Error: Bay ID must be a valid number", true);
        return;
    }

    if (!mechanicIdRaw || isNaN(mechanicIdRaw)) {
        showToast("Error: Mechanic ID must be a valid number", true);
        return;
    }

    const body = {
        bayId: Number(bayIdRaw),
        mechanicId: Number(mechanicIdRaw)
    };

    try {
        await apiRequest(`${API}/job-cards/${jobIdRaw}/assign`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body)
        });

        showToast("Bay and mechanic assigned successfully");
        await loadJobs();
    } catch (error) {
        console.error(error);
    }
}

/* ==========================
   6. JOB WORKFLOW
========================== */
function selectedWorkflowJob() {
    const id = document.getElementById("workflowJobId").value;

    if (!id || isNaN(id)) {
        showToast("Error: Please select a valid job card", true);
        return null;
    }

    return id;
}

async function startJob() {
    const id = selectedWorkflowJob();
    if (!id) return;

    try {
        await apiRequest(`${API}/job-cards/${id}/start`, { method: "PUT" });
        showToast("Job started successfully");
        await loadJobs();
    } catch (error) {
        console.error(error);
    }
}

async function moveToQualityCheck() {
    const id = selectedWorkflowJob();
    if (!id) return;

    try {
        await apiRequest(`${API}/job-cards/${id}/quality-check`, { method: "PUT" });
        showToast("Job moved to quality check");
        await loadJobs();
    } catch (error) {
        console.error(error);
    }
}

async function passQualityCheck() {
    const id = selectedWorkflowJob();
    if (!id) return;

    try {
        await apiRequest(`${API}/job-cards/${id}/quality-check/pass`, { method: "PUT" });
        showToast("Quality check passed");
        await loadJobs();
    } catch (error) {
        console.error(error);
    }
}

async function completeJob() {
    const id = selectedWorkflowJob();
    if (!id) return;

    try {
        await apiRequest(`${API}/job-cards/${id}/complete`, { method: "PUT" });
        showToast("Job marked as completed");
        await loadJobs();
    } catch (error) {
        console.error(error);
    }
}

/* ==========================
   7. BILLING
========================= */
async function generateBill(event) {
    event.preventDefault();

    const jobIdRaw = document.getElementById("billJobId").value;
    const labourEl = document.getElementById("labourCharge");
    const partsEl = document.getElementById("partsTotal");

    if (!jobIdRaw || isNaN(jobIdRaw)) {
        showToast("Error: Job Card ID must be a valid number", true);
        return;
    }

    if (labourEl.validity && labourEl.validity.badInput) {
        showToast("Error: Labour charge must be a valid numeric value, not a string", true);
        return;
    }

    if (partsEl.validity && partsEl.validity.badInput) {
        showToast("Error: Parts total must be a valid numeric value, not a string", true);
        return;
    }

    const labourRaw = labourEl.value.trim();
    const partsRaw = partsEl.value.trim();

    if (!labourRaw || isNaN(labourRaw)) {
        showToast("Error: Labour charge must be a valid numeric value, not a string", true);
        return;
    }

    if (Number(labourRaw) < 0) {
        showToast("Error: Labour charge cannot be negative", true);
        return;
    }

    if (!partsRaw || isNaN(partsRaw)) {
        showToast("Error: Parts total must be a valid numeric value, not a string", true);
        return;
    }

    if (Number(partsRaw) < 0) {
        showToast("Error: Parts total cannot be negative", true);
        return;
    }

    const bill = {
        labourCharge: Number(labourRaw),
        partsTotal: Number(partsRaw)
    };

    try {
        const result = await apiRequest(`${API}/bills/job/${jobIdRaw}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(bill)
        });

        showBill(result);
        showToast("Bill generated successfully");
    } catch (error) {
        console.error(error);
    }
}

function showBill(bill) {
    const result = document.getElementById("billResult");
    result.classList.remove("hidden");

    result.innerHTML = `
        <h3>✅ Service Bill Generated</h3>
        <p><strong>Bill ID:</strong> #${bill.id}</p>
        <p><strong>Job Card ID:</strong> #${bill.jobCard ? bill.jobCard.id : "-"}</p>
        <p><strong>Labour Charge:</strong> ₹${Number(bill.labourCharge).toFixed(2)}</p>
        <p><strong>Parts Total:</strong> ₹${Number(bill.partsTotal).toFixed(2)}</p>
        <hr>
        <h3 style="color:#065f46; margin-top:8px;">Grand Total: ₹${Number(bill.grandTotal).toFixed(2)}</h3>
    `;
}

/* ==========================
   REFRESH ALL
========================== */
async function refreshAll() {
    await Promise.all([
        loadVehicles(),
        loadBays(),
        loadMechanics(),
        loadJobs()
    ]);
}

/* ==========================
   UTILITIES
========================== */
function formatDate(value) {
    if (!value) return "-";
    const d = new Date(value);
    return isNaN(d) ? value : d.toLocaleString();
}

function showToast(message, error = false) {
    const toast = document.getElementById("toast");
    if (!toast) return;

    toast.textContent = message;
    toast.className = `toast ${error ? 'error' : ''} show`;

    if (window.toastTimeout) clearTimeout(window.toastTimeout);
    window.toastTimeout = setTimeout(() => {
        toast.classList.remove("show");
    }, 3500);
}